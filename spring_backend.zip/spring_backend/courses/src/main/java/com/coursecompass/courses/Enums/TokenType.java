package com.coursecompass.courses.Enums;

public enum TokenType {
    BEARER
}
